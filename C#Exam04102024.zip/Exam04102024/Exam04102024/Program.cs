﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam04102024
{
    class Program
    {
        static void Main(string[] args)
        {
            Interface library = new Books();
            bool keepRunning = true;

            while (keepRunning)
            {
                try
                {
                    Console.WriteLine("Library Management System");
                    Console.WriteLine("1. Add a Book");
                    Console.WriteLine("2. View Book Details");
                    Console.WriteLine("3. Exit");
                    Console.Write("Choose an option (1/2/3): ");
                    string input = Console.ReadLine();

                    
                    if (int.TryParse(input, out int choice))
                    {
                        switch (choice)
                        {
                            case 1:
                                library.AddBooks();
                                break;
                            case 2:
                                library.GetBookDetails();
                                break;
                            case 3:
                                keepRunning = false;
                                Console.WriteLine("Exiting the application.");
                                break;
                            default:
                                Console.WriteLine("Invalid choice. Please choose 1, 2, or 3.\n");
                                break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. Please enter a valid number for your choice.\n");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("An error occurred: " + ex.Message);
                }
            }
        }
    }
}