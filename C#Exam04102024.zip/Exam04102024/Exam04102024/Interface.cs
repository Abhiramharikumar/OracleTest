﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam04102024
{ 
public interface Interface
{
    void AddBooks();
    void GetBookDetails();
}
}
