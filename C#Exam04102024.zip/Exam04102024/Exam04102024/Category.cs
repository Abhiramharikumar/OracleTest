﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam04102024
{
    public enum Category
    {
        Horror,
        Romance,
        Thriller,
        Survival,
        Zombie
    }
}
