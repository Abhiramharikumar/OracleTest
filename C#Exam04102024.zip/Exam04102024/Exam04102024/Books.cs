﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam04102024
{
    public class Books : Interface
    {
        private Dictionary<int, Book> bookDictionary = new Dictionary<int, Book>();

        public void AddBooks()
        {
            try
            {
                
                int id = GetValidBookID();

                if (bookDictionary.ContainsKey(id))
                {
                    Console.WriteLine("Book with this ID already exists.\n");
                    return;
                }

                
                string name = GetValidBookName();

                
                Category selectedCategory = GetValidCategory();

                
                bookDictionary.Add(id, new Book { BookID = id, BookName = name, BookCategory = selectedCategory });
                Console.WriteLine("Book added successfully!\n");
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
        }

        public void GetBookDetails()
        {
            if (bookDictionary.Count == 0)
            {
                Console.WriteLine("No books available in the library.\n");
                return;
            }

            Console.WriteLine("Library Books:");
            foreach (var book in bookDictionary.Values)
            {
                Console.WriteLine($"ID: {book.BookID}, Name: {book.BookName}, Category: {book.BookCategory}");
            }
            Console.WriteLine();
        }

        
        private int GetValidBookID()
        {
            int id;
            while (true)
            {
                Console.Write("Enter Book ID (numeric): ");
                string input = Console.ReadLine();

                if (int.TryParse(input, out id) && id > 0)
                {
                    return id;  
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid numeric Book ID greater than zero.");
                }
            }
        }

        
        private string GetValidBookName()
        {
            string name;
            while (true)
            {
                Console.Write("Enter Book Name: ");
                name = Console.ReadLine();

                if (!string.IsNullOrEmpty(name))
                {
                    return name;  
                }
                else
                {
                    Console.WriteLine("Book name cannot be empty. Please try again.");
                }
            }
        }

        
        private Category GetValidCategory()
        {
            int categoryChoice;
            while (true)
            {
                
                Console.WriteLine("Choose a Category: ");
                foreach (var category in Enum.GetValues(typeof(Category)))
                {
                    Console.WriteLine($"{(int)category} - {category}");
                }

                
                Console.Write("Enter the number corresponding to the category: ");
                string input = Console.ReadLine();

                if (int.TryParse(input, out categoryChoice) && Enum.IsDefined(typeof(Category), categoryChoice))
                {
                    return (Category)categoryChoice;  
                }
                else
                {
                    Console.WriteLine("Invalid category selection. Please choose a valid number from the list.");
                }
            }
        }
    }
}