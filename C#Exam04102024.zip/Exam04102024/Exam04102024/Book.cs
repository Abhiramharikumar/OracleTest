﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam04102024
{
    public class Book
    {
        public int BookID { get; set; }
        public string BookName { get; set; }
        public Category BookCategory { get; set; }
    }
}
